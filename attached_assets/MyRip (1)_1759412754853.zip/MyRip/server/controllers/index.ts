export * from './userController';
export * from './residentController';
export * from './teacherController';