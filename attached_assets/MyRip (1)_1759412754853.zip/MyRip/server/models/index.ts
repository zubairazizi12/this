export * from './User';
export * from './Resident';
export * from './Teacher';